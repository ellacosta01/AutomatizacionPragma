package com.automationpractice.portalweb.pruebas.stepdefinitions;

import cucumber.api.java.Before;
import cucumber.api.java.es.Dado;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.actors.OnStage;
import net.serenitybdd.screenplay.actors.OnlineCast;

public class Hook {

    private static Actor actor;
    private OnlineCast theCast = new OnlineCast();

    @Before
    public void setTheStage() {
        OnStage.setTheStage(theCast);
    }

    @Dado("^que Ella usara el navegador \"([^\"]*)\"$")
    public void queEllaUsaraElNavegador(String navegador) {
        actor = theCast.actorUsingBrowser(navegador).named("Ella");
    }

    public static Actor actorGlobal(){
        return actor;
    }

}
