package com.automationpractice.portalweb.pruebas.stepdefinitions;

import com.automationpractice.portalweb.pruebas.questions.ElProductoBuscado;
import cucumber.api.java.es.Cuando;
import cucumber.api.java.es.Entonces;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.actions.Enter;
import org.hamcrest.Matchers;
import org.openqa.selenium.Keys;

import static com.automationpractice.portalweb.pruebas.userinterfaces.HomePage.CAMPO_DE_BUSQUEDA;
import static net.serenitybdd.screenplay.GivenWhenThen.seeThat;

public class ConsultarProductoStepDefinitions {

    Actor actor;

    @Cuando("^busca el producto \"([^\"]*)\"$")
    public void buscaElProducto(String producto) {
        actor=Hook.actorGlobal();
        actor.attemptsTo(Enter.theValue(producto).into(CAMPO_DE_BUSQUEDA).thenHit(Keys.ENTER));
    }


    @Entonces("^el producto \"([^\"]*)\" con precio \"([^\"]*)\" deberia estar presente el producto entre los resultados$")
    public void elProductoDeberiaEstarPresenteElProductoEntreLosResultados(String producto, String precio) {
        actor.should(seeThat(ElProductoBuscado.esVisible(producto, precio), Matchers.equalTo(true)));
    }

    @Entonces("^el producto \"([^\"]*)\" con precio \"([^\"]*)\" no deberia estar presente el producto entre los resultados$")
    public void elProductoNoDeberiaEstarPresenteElProductoEntreLosResultados(String producto, String precio) {
        actor.should(seeThat(ElProductoBuscado.esVisible(producto, precio), Matchers.equalTo(false)));
    }
}
