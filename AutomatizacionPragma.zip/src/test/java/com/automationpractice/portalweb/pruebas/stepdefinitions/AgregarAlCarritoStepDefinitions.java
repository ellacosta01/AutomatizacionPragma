package com.automationpractice.portalweb.pruebas.stepdefinitions;

import com.automationpractice.portalweb.pruebas.interactions.Esperar;
import com.automationpractice.portalweb.pruebas.questions.*;
import com.automationpractice.portalweb.pruebas.userinterfaces.CarritoDeComprasPage;
import com.automationpractice.portalweb.pruebas.userinterfaces.HomePage;
import cucumber.api.java.es.Cuando;
import cucumber.api.java.es.Entonces;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.actions.Click;
import net.serenitybdd.screenplay.actions.MoveMouse;
import net.serenitybdd.screenplay.actions.Scroll;
import org.hamcrest.Matchers;

import java.util.List;

import static com.automationpractice.portalweb.pruebas.stepdefinitions.Hook.actorGlobal;
import static com.automationpractice.portalweb.pruebas.userinterfaces.HomePage.ADD_TO_CART;
import static net.serenitybdd.screenplay.GivenWhenThen.seeThat;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.is;

public class AgregarAlCarritoStepDefinitions {

    Actor actor;

    @Cuando("^agrega el producto \"([^\"]*)\" con precio \"([^\"]*)\"$")
    public void agregaElProductoConPrecio(String nombreProducto, String precio) {
        actor=actorGlobal();
        actor.attemptsTo(MoveMouse.to(HomePage.PRODUCTO(nombreProducto, precio)));
        actor.attemptsTo(Click.on(ADD_TO_CART(nombreProducto, precio)));
    }

    @Entonces("^deberia ver un anuncio del producto \"([^\"]*)\" agregado al carrito$")
    public void deberiaVerUnAnuncioDelProductoAgregadoAlCarrito(String nombreProducto) {
        actor.attemptsTo(Esperar.unTiempoDe(2000));
        actor.should(seeThat(ElProducto.recienAgregadoAlCarrito(), is(nombreProducto)));
    }

    @Entonces("^deberia ver los siguientes precios$")
    public void deberiaVerLosSiguientesPrecios(List<List<String>> listaPrecios) {
        actor.should(seeThat(ElValor.actualizadoDelCarrito(listaPrecios.get(0).get(0),HomePage.TOTAL_ACTUALIZADO),equalTo(listaPrecios.get(0).get(1))));
        actor.should(seeThat(ElValor.actualizadoDelCarrito(listaPrecios.get(1).get(0),HomePage.TOTAL_SHIPPING),equalTo(listaPrecios.get(1).get(1))));
        actor.should(seeThat(ElValor.actualizadoDelCarrito(listaPrecios.get(2).get(0),HomePage.TOTAL_ACTUALIZADO),equalTo(listaPrecios.get(2).get(1))));
    }

    @Cuando("^procede a hacer checkout$")
    public void procedeAHacerCheckout() {
        actor.attemptsTo(Click.on(HomePage.PROCEED_TO_CHECKOUT));
    }

    @Entonces("^deberia estar presente el producto \"([^\"]*)\"$")
    public void deberiaEstarPresenteElProducto(String producto) {
        actor.should(seeThat(EnElCarrito.estaElProducto(), equalTo(producto)));
    }

    @Entonces("^deberia ver los siguientes precios de sus compras$")
    public void deberiaVerLosSiguientesPreciosDeSusCompras(List<List<String>> lista) {
        actor.attemptsTo(Scroll.to(CarritoDeComprasPage.GRAN_TOTAL).andAlignToBottom());
        actor.should(seeThat(ElTotalEntreProductos.enElCarrito(), Matchers.is(lista.get(0).get(1))));
        actor.should(seeThat(ElTotalDeEnvio.enElCarrito(), Matchers.is(lista.get(1).get(1))));
        actor.should(seeThat(ElTotalSinImpuesto.enElCarrito(), Matchers.is(lista.get(2).get(1))));
        actor.should(seeThat(ElImpuestoTotal.enElCarrito(), Matchers.is(lista.get(3).get(1))));
        actor.should(seeThat(ElGranTotal.enElCarrito(), Matchers.is(lista.get(4).get(1))));
    }















}
