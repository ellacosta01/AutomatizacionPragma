package com.automationpractice.portalweb.pruebas.stepdefinitions;

import com.automationpractice.portalweb.pruebas.questions.ElNombre;
import com.automationpractice.portalweb.pruebas.questions.HayUnMensajeDeError;
import com.automationpractice.portalweb.pruebas.questions.LaVisibilidadDelNombre;
import com.automationpractice.portalweb.pruebas.tasks.IniciarSesion;
import com.automationpractice.portalweb.pruebas.userinterfaces.HomePage;
import cucumber.api.java.es.Cuando;
import cucumber.api.java.es.Dado;
import cucumber.api.java.es.Entonces;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.actions.Click;
import net.serenitybdd.screenplay.actions.Open;

import java.util.List;

import static com.automationpractice.portalweb.pruebas.stepdefinitions.Hook.actorGlobal;
import static net.serenitybdd.screenplay.GivenWhenThen.seeThat;
import static org.hamcrest.Matchers.equalTo;

public class IniciarSesionStepDefinitions {

    Actor actor;

    @Dado("^ingresa al home de Automation Practice$")
    public void ingresaAlHomeDeAutomationPractice() {
        actor=actorGlobal();
        actor.attemptsTo(Open.url("http://automationpractice.com/index.php"));
    }

    @Dado("^se dirige a la pagina de Sign in$")
    public void seDirigeALaPaginaDeSignIn() {
        actor.attemptsTo(Click.on(HomePage.BTN_SIGN_IN));
    }

    @Cuando("^inicia sesion con sus credenciales \"([^\"]*)\" y \"([^\"]*)\"$")
    public void iniciaSesionConSusCredencialesY(String email, String clave) {
        actor.attemptsTo(IniciarSesion.conLasCredenciales(email, clave));
    }

    @Entonces("^deberia ver su nombre \"([^\"]*)\" en el menu superior derecho$")
    public void deberiaVerSuNombreEnElMenuSuperiorDerecho(String nombreCuenta) {
        actor.should(seeThat(ElNombre.deLaCuenta(), equalTo(nombreCuenta)));
    }

    @Cuando("^regresa a la pagina Home$")
    public void regresaALaPaginaHome() {
        actor.attemptsTo(Click.on(HomePage.LOGO));
    }

    @Entonces("^no deberia ver su nombre en el menu superior derecho$")
    public void noDeberiaVerSuNombreEnElMenuSuperiorDerecho() {
        actor.should(seeThat(LaVisibilidadDelNombre.deLaCuenta(), equalTo(false)));
    }

    @Entonces("^deberia ver un mensaje de error de autenticacion$")
    public void deberiaVerUnMensajeDeErrorDeAutenticacion(List<String> mensajeDeError) {
        actor.should(seeThat(HayUnMensajeDeError.enLaPantalla(), equalTo(mensajeDeError.get(0))));
    }
}
