package com.automationpractice.portalweb.pruebas.questions;

import com.automationpractice.portalweb.pruebas.userinterfaces.CarritoDeComprasPage;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Question;
import net.serenitybdd.screenplay.questions.Text;

public class ElTotalSinImpuesto implements Question<String> {
    @Override
    public String answeredBy(Actor actor) {
        return Text.of(CarritoDeComprasPage.PRECIO_TOTAL_SIN_IMPUESTO).viewedBy(actor).asString();
    }

    public static ElTotalSinImpuesto enElCarrito(){
        return new ElTotalSinImpuesto();
    }
}
