package com.automationpractice.portalweb.pruebas.tasks;

import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Task;
import net.serenitybdd.screenplay.Tasks;
import net.serenitybdd.screenplay.actions.Enter;
import net.serenitybdd.screenplay.actions.Hit;
import org.openqa.selenium.Keys;

import static com.automationpractice.portalweb.pruebas.userinterfaces.SignInPage.TXT_EMAIL;
import static com.automationpractice.portalweb.pruebas.userinterfaces.SignInPage.TXT_PASSWORD;

public class IniciarSesion implements Task {

    String email;
    String password;

    public IniciarSesion(String email, String password) {
        this.email = email;
        this.password = password;
    }

    @Override
    public <T extends Actor> void performAs(T actor) {
        actor.attemptsTo(
                Enter.theValue(email).into(TXT_EMAIL),
                Enter.theValue(password).into(TXT_PASSWORD),
                Hit.the(Keys.ENTER).into(TXT_PASSWORD)
        );
    }

    public static IniciarSesion conLasCredenciales(String email, String password) {
        return Tasks.instrumented(IniciarSesion.class, email, password);
    }

}
