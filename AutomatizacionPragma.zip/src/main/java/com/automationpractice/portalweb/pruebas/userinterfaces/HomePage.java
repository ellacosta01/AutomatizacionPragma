package com.automationpractice.portalweb.pruebas.userinterfaces;

import net.serenitybdd.screenplay.targets.Target;
import org.openqa.selenium.By;

public class HomePage {

    public static final Target BTN_SIGN_IN = Target.the("Boton de Sign in").
            located(By.xpath("//a[@class='login']"));
    public static final Target PRODUCTO_AGREGADO=Target.the("Producto agregado").
            locatedBy("//span[@id='layer_cart_product_title']");
    public static final Target TOTAL_ACTUALIZADO=Target.the("Valor total actualizado").
            locatedBy("//strong[normalize-space()='{0}']/following-sibling::span[@class]");
    public static final Target TOTAL_SHIPPING=Target.the("Valor total de envios actualizado").
            locatedBy("//strong[contains(text(),'{0}')]/following-sibling::span[@class]");
    public static final Target PROCEED_TO_CHECKOUT=Target.the("Proceed to checkout").locatedBy("//span[normalize-space()='Proceed to checkout']");
    public static final Target CAMPO_DE_BUSQUEDA=Target.the("Buscador").locatedBy("//input[@id='search_query_top']");
    public static final Target LOGO=Target.the("Logo").locatedBy("//img[@alt='My Store']");
    public static Target PRODUCTO(String nombreProducto, String precio){
        return Target.the("Producto "+ nombreProducto + "con precio "+ precio).
                locatedBy("(//li[descendant::a[@title='" + nombreProducto + "'] and descendant::span[contains(text(),'" + precio + "')]])[1]");
    }
    public static Target ADD_TO_CART(String nombreProducto, String precio){
        return Target.the("Agregar al carrito").
                locatedBy("(//li[descendant::a[@title='" + nombreProducto +
                        "'] and descendant::span[contains(text(),'" + precio + "')]])[1]/descendant::span[text()='Add to cart']");
    }
}
