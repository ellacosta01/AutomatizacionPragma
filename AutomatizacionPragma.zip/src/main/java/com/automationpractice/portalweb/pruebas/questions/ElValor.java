package com.automationpractice.portalweb.pruebas.questions;

import com.automationpractice.portalweb.pruebas.userinterfaces.HomePage;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Question;
import net.serenitybdd.screenplay.questions.Text;
import net.serenitybdd.screenplay.targets.Target;

public class ElValor implements Question<String> {

    String totalAValidar;
    Target mapeoTotalAValidar;
    public ElValor(String totalAValidar, Target mapeoTotalAValidar) {
        this.totalAValidar = totalAValidar;
        this.mapeoTotalAValidar=mapeoTotalAValidar;
    }

    @Override
    public String answeredBy(Actor actor) {
        return Text.of(mapeoTotalAValidar.of(totalAValidar)).viewedBy(actor).asString();
    }

    public static ElValor actualizadoDelCarrito(String totalAValidar, Target mapeoTotalAValidar){
        return new ElValor(totalAValidar, mapeoTotalAValidar);
    }
}
