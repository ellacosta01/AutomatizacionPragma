package com.automationpractice.portalweb.pruebas.userinterfaces;

import net.serenitybdd.screenplay.targets.Target;
import org.openqa.selenium.By;

public class CuentaPage {

    public static final Target TXT_NOMBRE_CUENTA = Target.the("Nombre del titular de la cuenta").located(By.xpath("//a[@class='account']"));
}
