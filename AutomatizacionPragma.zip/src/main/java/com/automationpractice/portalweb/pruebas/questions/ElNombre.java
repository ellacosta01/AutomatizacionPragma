package com.automationpractice.portalweb.pruebas.questions;

import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Question;
import net.serenitybdd.screenplay.questions.Text;

import static com.automationpractice.portalweb.pruebas.userinterfaces.CuentaPage.TXT_NOMBRE_CUENTA;

public class ElNombre implements Question<String> {


    @Override
    public String answeredBy(Actor actor) {
        return Text.of(TXT_NOMBRE_CUENTA).viewedBy(actor).asString();
    }

    public static ElNombre deLaCuenta() {
        return new ElNombre();
    }
}

