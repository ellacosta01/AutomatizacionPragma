package com.automationpractice.portalweb.pruebas.questions;

import com.automationpractice.portalweb.pruebas.userinterfaces.CarritoDeComprasPage;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Question;
import net.serenitybdd.screenplay.questions.Text;

public class EnElCarrito implements Question<String> {

    public static EnElCarrito estaElProducto() {
        return new EnElCarrito();
    }

    @Override
    public String answeredBy(Actor actor) {
        return Text.of(CarritoDeComprasPage.PRODUCTO_AGREGADO).viewedBy(actor).asString();
    }


}
