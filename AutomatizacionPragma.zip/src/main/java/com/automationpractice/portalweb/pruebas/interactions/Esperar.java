package com.automationpractice.portalweb.pruebas.interactions;

import net.serenitybdd.core.time.InternalSystemClock;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Interaction;
import net.serenitybdd.screenplay.Tasks;

public class Esperar implements Interaction {
    int tiempo;
    public Esperar(int tiempo){
        this.tiempo=tiempo;
    }

    public static Esperar unTiempoDe(int tiempo) {
        return Tasks.instrumented(Esperar.class, tiempo);
    }

    @Override
    public <T extends Actor> void performAs(T actor) {
        new InternalSystemClock().pauseFor(tiempo);
    }
}
