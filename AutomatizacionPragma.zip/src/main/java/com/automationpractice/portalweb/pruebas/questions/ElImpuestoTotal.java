package com.automationpractice.portalweb.pruebas.questions;

import com.automationpractice.portalweb.pruebas.userinterfaces.CarritoDeComprasPage;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Question;
import net.serenitybdd.screenplay.questions.Text;

public class ElImpuestoTotal implements Question<String> {

    @Override
    public String answeredBy(Actor actor) {
        return Text.of(CarritoDeComprasPage.IMPUESTO_TOTAL).viewedBy(actor).asString();
    }

    public static ElImpuestoTotal enElCarrito(){
        return new ElImpuestoTotal();
    }
}
