package com.automationpractice.portalweb.pruebas.questions;

import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Question;

import static com.automationpractice.portalweb.pruebas.userinterfaces.CuentaPage.TXT_NOMBRE_CUENTA;

public class LaVisibilidadDelNombre implements Question<Boolean> {

    public static LaVisibilidadDelNombre deLaCuenta(){
        return new LaVisibilidadDelNombre();
    }

    @Override
    public Boolean answeredBy(Actor actor) {
        if (TXT_NOMBRE_CUENTA.resolveAllFor(actor).size() > 0) return true;
        else return false;

    }
}
