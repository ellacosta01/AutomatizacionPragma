package com.automationpractice.portalweb.pruebas.questions;

import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Question;
import net.serenitybdd.screenplay.questions.Text;

import static com.automationpractice.portalweb.pruebas.userinterfaces.SignInPage.MENSAJE_ERROR;

public class HayUnMensajeDeError implements Question<String> {
    public static HayUnMensajeDeError enLaPantalla() {
        return new HayUnMensajeDeError();
    }

    @Override
    public String answeredBy(Actor actor) {
        return Text.of(MENSAJE_ERROR).viewedBy(actor).asString();
    }
}
