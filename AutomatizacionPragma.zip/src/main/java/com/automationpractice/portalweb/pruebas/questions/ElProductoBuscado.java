package com.automationpractice.portalweb.pruebas.questions;

import com.automationpractice.portalweb.pruebas.userinterfaces.HomePage;
import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Question;

public class ElProductoBuscado implements Question<Boolean> {

    String producto;
    String precio;

    public ElProductoBuscado(String producto, String precio) {
        this.precio=precio;
        this.producto=producto;
    }

    @Override
    public Boolean answeredBy(Actor actor) {
        if(HomePage.PRODUCTO(producto, precio).resolveAllFor(actor).size() > 0)
        return HomePage.PRODUCTO(producto, precio).resolveFor(actor).isVisible();
        else return false;
    }

    public static ElProductoBuscado esVisible(String producto, String precio){
        return new ElProductoBuscado(producto, precio);
    }
}
