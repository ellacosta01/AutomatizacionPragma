package com.automationpractice.portalweb.pruebas.userinterfaces;

import net.serenitybdd.screenplay.targets.Target;
import org.openqa.selenium.By;

public class SignInPage {
    public static final Target TXT_EMAIL = Target.the("Campo email").located(By.xpath("//input[@id='email']"));
    public static final Target TXT_PASSWORD = Target.the("Campo clave").located(By.xpath("//input[@id='passwd']"));
    public static final Target MENSAJE_ERROR=Target.the("Mensaje de error").locatedBy("//div[@class='alert alert-danger']//descendant::li");
}
