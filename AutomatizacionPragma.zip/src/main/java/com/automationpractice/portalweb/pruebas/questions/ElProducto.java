package com.automationpractice.portalweb.pruebas.questions;

import net.serenitybdd.screenplay.Actor;
import net.serenitybdd.screenplay.Question;
import net.serenitybdd.screenplay.questions.Text;

import static com.automationpractice.portalweb.pruebas.userinterfaces.HomePage.PRODUCTO_AGREGADO;

public class ElProducto implements Question<String> {

    public static ElProducto recienAgregadoAlCarrito() {
        return new ElProducto();
    }

    @Override
    public String answeredBy(Actor actor) {
        return Text.of(PRODUCTO_AGREGADO).viewedBy(actor).asString();
    }
}
