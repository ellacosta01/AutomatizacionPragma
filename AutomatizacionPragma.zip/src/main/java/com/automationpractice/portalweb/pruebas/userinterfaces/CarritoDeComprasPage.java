package com.automationpractice.portalweb.pruebas.userinterfaces;

import net.serenitybdd.screenplay.targets.Target;

public class CarritoDeComprasPage {
    public static final Target PRODUCTO_AGREGADO=Target.the("Producto agregado").locatedBy("(//p[@class='product-name'])[2]/a");
    public static final Target TOTAL_ENTRE_PRODUCTOS=Target.the("Total entre productos").locatedBy("//td[@id='total_product']");
    public static final Target TOTAL_DE_ENVIO=Target.the("Total de envio").locatedBy("//td[@id='total_shipping']");
    public static final Target PRECIO_TOTAL_SIN_IMPUESTO=Target.the("Total sin impuestos").locatedBy("//td[@id='total_price_without_tax']");
    public static final Target IMPUESTO_TOTAL=Target.the("Impuesto total").locatedBy("//td[@id='total_tax']");
    public static final Target GRAN_TOTAL=Target.the("Gran total").locatedBy("//span[@id='total_price']");




}
